﻿# -*- coding: utf-8 -*-
import os

from flask import Flask, redirect, url_for, send_file, request, abort
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, current_user, UserMixin

login_manager = LoginManager()
db = SQLAlchemy()
migrate = Migrate()


@login_manager.user_loader
def load_user(username):
    """Загрузчик пользователя для Flask-Login"""
    from .public.auth.auth import USERS, SimpleUser
    if username in USERS:
        return SimpleUser(username)
    return None


def create_app():
    app = Flask(__name__, instance_relative_config=True,
                template_folder='templates',
                static_folder='static')
    app.config.from_object("config.Config")

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .public.routes import public_bp
    from .public.auth import auth_bp
    from .admin import admin_bp

    # ── CSRF global ──────────────────────────────────────────────
    from .csrf import generate_csrf_token
    app.jinja_env.globals['csrf_token'] = generate_csrf_token
    # ─────────────────────────────────────────────────────────────

    @admin_bp.before_request
    def before_request():
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login"))

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # ── Secure file download route ────────────────────────────────
    @app.route('/lab-file/<int:file_id>')
    def lab_file_download(file_id):
        """Serve lab files with path-traversal protection."""
        from app.models import LabFile
        lf = LabFile.query.get_or_404(file_id)

        # app.root_path  → …/test/app
        # base           → …/test
        base = os.path.abspath(os.path.dirname(app.root_path))
        full_path = os.path.abspath(os.path.join(base, lf.file_path))
        labs_dir = os.path.abspath(os.path.join(base, 'instance', 'labs'))

        # Ensure the resolved path stays inside instance/labs/
        if not full_path.startswith(labs_dir + os.sep) and full_path != labs_dir:
            from flask import abort
            abort(403)

        if not os.path.isfile(full_path):
            from flask import abort
            abort(404)

        return send_file(full_path, as_attachment=True)
    # ─────────────────────────────────────────────────────────────

    # ── Security headers ──────────────────────────────────────────
    @app.after_request
    def set_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        return response
    # ─────────────────────────────────────────────────────────────


    # ── IP whitelist ──────────────────────────────────────────────
    import ipaddress

    ALLOWED_NETWORKS = [
        ipaddress.ip_network('10.24.182.0/24'),
    ]
    ALLOWED_IPS = {
        '10.22.11.138', '10.22.11.178',
    }

    @app.before_request
    def check_ip():
        # remote_addr — реальный IP если без прокси,
        # или IP прокси (127.0.0.1) если за nginx/gunicorn
        real_ip = request.remote_addr

        # Если за прокси — берём X-Forwarded-For (только первый IP из списка)
        forwarded = request.headers.get('X-Forwarded-For')
        if forwarded:
            real_ip = forwarded.split(',')[0].strip()

        try:
            addr = ipaddress.ip_address(real_ip)
        except ValueError:
            abort(403)

        # Разрешён конкретный IP?
        if real_ip in ALLOWED_IPS:
            return

        # Разрешён в подсети?
        for net in ALLOWED_NETWORKS:
            if addr in net:
                return

        abort(403)
    # ─────────────────────────────────────────────────────────────

    return app