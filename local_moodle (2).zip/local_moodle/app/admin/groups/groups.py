from flask import render_template, request, abort, jsonify

from .__blueprint__ import admin_groups_bp
from app import db
from app.models import Group, Student, Lab
from app.csrf import validate_csrf_token


@admin_groups_bp.route('/edit_groups')
def edit_groups():
    groups = list(db.session.query(Group).all())
    return render_template("admin/edit_groups.html", groups=groups)


@admin_groups_bp.route('/add_group', methods=['POST'])
def add_group():
    # JSON-запросы защищены Same-Origin Policy браузера + CSRF-токен в заголовке
    if not validate_csrf_token():
        abort(403)
    data = request.json
    if not data or 'name' not in data:
        return jsonify({'success': False, 'error': 'Отсутствует название группы'}), 400
    try:
        size = int(data.get('size', 0))
    except (ValueError, TypeError):
        return jsonify({'success': False, 'error': 'Неверный размер группы'}), 400

    existing_group = Group.query.filter_by(name=data['name']).first()
    if existing_group:
        existing_group.size = size
    else:
        group = Group(name=data['name'], size=size)
        db.session.add(group)
    db.session.commit()
    return jsonify({'success': True})


@admin_groups_bp.route('/remove_group', methods=['POST'])
def remove_group():
    if not validate_csrf_token():
        abort(403)
    data = request.json
    if not data or 'name' not in data:
        return jsonify({'success': False, 'error': 'Отсутствует название группы'}), 400

    group = Group.query.filter_by(name=data['name']).first()
    if not group:
        return jsonify({'success': False, 'error': 'Группа не найдена'}), 404

    # ИСПРАВЛЕНО: проверка связанных студентов и лабораторных перед удалением
    student_count = Student.query.filter_by(group_id=group.id).count()
    if student_count > 0:
        return jsonify({
            'success': False,
            'error': f'Нельзя удалить группу: в ней {student_count} студент(ов). Сначала удалите студентов.'
        }), 409

    if group.labs:
        return jsonify({
            'success': False,
            'error': f'Нельзя удалить группу: она привязана к {len(group.labs)} лабораторн(ым). Сначала открепите группу от работ.'
        }), 409

    db.session.delete(group)
    db.session.commit()
    return jsonify({'success': True})
