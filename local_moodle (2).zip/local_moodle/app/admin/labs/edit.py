from flask import render_template, request, Blueprint, Response, abort, jsonify
from .__blueprint__ import admin_labs_bp
from app import db
from app.models import Group, Lab, LabFile, Question, FileQuestionAnswer, LabPassword
from app.csrf import validate_csrf_token
import base64
import os
import xml.etree.ElementTree as ET
from datetime import datetime
import pytz
import secrets
import string
import re as _re

MSK = pytz.timezone('Europe/Moscow')

_SAFE_FILENAME = _re.compile(r'^[\w\-. ]+$')
_MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB


def _sanitize_filename(name: str) -> str:
    """Убирает компоненты директорий и отклоняет опасные имена файлов."""
    name = os.path.basename(name).strip()
    if not name or not _SAFE_FILENAME.match(name):
        raise ValueError(f'Недопустимое имя файла: {name!r}')
    return name


def _safe_b64decode(b64_str: str) -> bytes:
    if "," in b64_str:
        b64_str = b64_str.split(",", 1)[1]
    data = base64.b64decode(b64_str)
    if len(data) > _MAX_FILE_SIZE:
        raise ValueError("Файл слишком большой (макс. 50 МБ)")
    return data


def _safe_write(files_dir: str, name: str, content: bytes) -> str:
    """Записывает файл, гарантируя, что путь остаётся внутри files_dir."""
    safe_name = _sanitize_filename(name)
    file_path = os.path.join(files_dir, safe_name)
    abs_base = os.path.abspath(files_dir)
    abs_path = os.path.abspath(file_path)
    if not abs_path.startswith(abs_base + os.sep):
        raise ValueError("Недопустимый путь файла")
    with open(abs_path, "wb") as fp:
        fp.write(content)
    return abs_path


def generate_password(length=10):
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def ensure_lab_passwords(lab_id):
    lab = Lab.query.get(lab_id)
    if not lab:
        return []
    if lab.passwords:
        return lab.passwords
    passwords = []
    for f in LabFile.query.filter_by(lab_id=lab_id):
        pwd = LabPassword(lab_id=lab.id, file_id=f.id, password=generate_password(10))
        db.session.add(pwd)
        passwords.append(pwd)
    db.session.commit()
    return passwords


@admin_labs_bp.route("/list")
def list_labs():
    groups = Group.query.all()
    labs = Lab.query.order_by(Lab.start_at.desc()).all()
    return render_template("admin/labs_list.html", labs=labs, groups=groups)


@admin_labs_bp.route("/delete/<int:lab_id>", methods=["POST"])
def delete_lab(lab_id):
    # Для fetch-запроса принимаем токен из заголовка или формы
    if not validate_csrf_token():
        abort(403)

    lab = Lab.query.get(lab_id)
    if not lab:
        return {"success": False, "error": "ЛР не найдена"}

    FileQuestionAnswer.query.filter(FileQuestionAnswer.question_id.in_(
        db.session.query(Question.id).filter_by(lab_id=lab_id)
    )).delete(synchronize_session=False)

    Question.query.filter_by(lab_id=lab_id).delete()
    LabFile.query.filter_by(lab_id=lab_id).delete()
    LabPassword.query.filter_by(lab_id=lab_id).delete()
    db.session.commit()
    db.session.delete(lab)
    db.session.commit()

    return {"success": True}


@admin_labs_bp.route("/edit_lab/<int:lab_id>")
def edit_lab(lab_id):
    lab = Lab.query.get_or_404(lab_id)
    files = []
    for f in LabFile.query.filter_by(lab_id=lab_id).all():
        files.append({"id": f.id, "name": os.path.basename(f.file_path)})
    questions = Question.query.filter_by(lab_id=lab_id).all()
    answers = FileQuestionAnswer.query.join(LabFile).filter(LabFile.lab_id == lab_id).all()
    answers_map = {}
    for ans in answers:
        answers_map.setdefault(ans.question_id, {})[ans.lab_file_id] = ans.correct_answer
    groups = Group.query.all()
    return render_template(
        "admin/edit_lab.html",
        lab=lab, files=files, questions=questions,
        answers=answers_map, groups=groups
    )


@admin_labs_bp.route("/edit_lab/<int:lab_id>", methods=["POST"])
def update_lab(lab_id):
    # ИСПРАВЛЕНО: добавлена проверка CSRF для JSON-эндпоинта
    if not validate_csrf_token():
        abort(403)
    data = request.json
    lab = Lab.query.get_or_404(lab_id)

    start_dt = datetime.fromisoformat(data['start_date'])
    deadline_dt = datetime.fromisoformat(data['deadline'])
    if start_dt.tzinfo is None:
        start_dt = MSK.localize(start_dt).replace(tzinfo=None)
    if deadline_dt.tzinfo is None:
        deadline_dt = MSK.localize(deadline_dt).replace(tzinfo=None)

    lab.title = data['name']
    lab.description = data['description']
    lab.start_at = start_dt
    lab.deadline_at = deadline_dt
    lab.is_test = data.get('is_test', False)
    lab.questions_count = int(data.get('questions_count', 0))
    lab.test_duration = int(data.get('test_duration', 0))

    group_ids = [int(g) for g in data['groups']]
    lab.groups = Group.query.filter(Group.id.in_(group_ids)).all()

    existing_files = {f.id: f for f in LabFile.query.filter_by(lab_id=lab_id).all()}
    new_files = data['files']

    files_dir = os.path.join("instance", "labs", str(lab.id))
    os.makedirs(files_dir, exist_ok=True)

    # 1. Удаляем файлы
    for f in new_files:
        if f.get("action") == "delete":
            file_id = f["id"]
            if file_id in existing_files:
                try:
                    os.remove(existing_files[file_id].file_path)
                except OSError:
                    pass
                db.session.delete(existing_files[file_id])
                existing_files.pop(file_id)

    # 2. Заменяем файлы — ИСПРАВЛЕНО: _sanitize_filename теперь вызывается и здесь
    for f in new_files:
        if f.get("action") == "replace":
            file_id = f["id"]
            if file_id in existing_files:
                try:
                    os.remove(existing_files[file_id].file_path)
                except OSError:
                    pass
                try:
                    safe_name = _sanitize_filename(f['name'])
                    content = _safe_b64decode(f['base64'])
                    abs_path = _safe_write(files_dir, safe_name, content)
                except ValueError as exc:
                    return jsonify({'success': False, 'error': str(exc)}), 400
                existing_files[file_id].file_path = abs_path

    # 3. Добавляем новые файлы
    for f in new_files:
        if f.get("action") == "add":
            try:
                safe_name = _sanitize_filename(f['name'])
                content = _safe_b64decode(f['base64'])
                abs_path = _safe_write(files_dir, safe_name, content)
            except ValueError as exc:
                return jsonify({'success': False, 'error': str(exc)}), 400
            lf = LabFile(lab_id=lab.id, file_path=abs_path)
            db.session.add(lf)
            db.session.flush()
            existing_files[lf.id] = lf

    Question.query.filter_by(lab_id=lab_id).delete()
    db.session.flush()

    question_objs = []
    for q in data['questions']:
        q_obj = Question(lab_id=lab.id, text=q['text'])
        db.session.add(q_obj)
        question_objs.append(q_obj)

    db.session.flush()

    db.session.query(FileQuestionAnswer).filter(
        FileQuestionAnswer.lab_file_id.in_(
            db.session.query(LabFile.id).filter(LabFile.lab_id == lab_id)
        )
    ).delete(synchronize_session=False)
    db.session.flush()

    for q, q_obj in zip(data['questions'], question_objs):
        for ans in q.get('answers', []):
            file_id = int(ans['file_id'])
            fqa = FileQuestionAnswer(
                lab_file_id=file_id,
                question_id=q_obj.id,
                correct_answer=ans['correct_answer']
            )
            db.session.add(fqa)

    db.session.commit()
    return {"success": True}


@admin_labs_bp.route("/<int:lab_id>/export_passwords_xml")
def export_passwords_xml(lab_id):
    lab = Lab.query.get_or_404(lab_id)
    passwords = ensure_lab_passwords(lab_id)

    quiz = ET.Element("quiz")
    category = ET.SubElement(quiz, "question", type="category")
    cattext = ET.SubElement(category, "category")
    cattext_text = ET.SubElement(cattext, "text")
    cattext_text.text = f"$course$/ЛР/{lab.title.replace(' ', '_')}"

    for idx, lp in enumerate(passwords, start=1):
        q = ET.SubElement(quiz, "question", type="essay")
        name = ET.SubElement(q, "name")
        ET.SubElement(name, "text").text = f"вариант {idx}"
        questiontext = ET.SubElement(q, "questiontext", format="html")
        ET.SubElement(questiontext, "text").text = (
            f"<p>Пароль для доступа к варианту №{idx}: "
            f"<strong>{lp.password}</strong></p>"
            f"<p>Загрузите изображение с результатом в виде файла.</p>"
        )
        gf = ET.SubElement(q, "generalfeedback", format="html")
        ET.SubElement(gf, "text").text = ""
        ET.SubElement(q, "defaultgrade").text = "1"
        ET.SubElement(q, "penalty").text = "0"
        ET.SubElement(q, "hidden").text = "0"
        ET.SubElement(q, "idnumber").text = ""
        ET.SubElement(q, "responseformat").text = "editorfilepicker"
        ET.SubElement(q, "responserequired").text = "1"
        ET.SubElement(q, "responsefieldlines").text = "10"
        ET.SubElement(q, "minwordlimit").text = ""
        ET.SubElement(q, "maxwordlimit").text = ""
        ET.SubElement(q, "attachments").text = "1"
        ET.SubElement(q, "attachmentsrequired").text = "1"
        ET.SubElement(q, "maxbytes").text = "0"
        ET.SubElement(q, "filetypeslist").text = ""
        gi = ET.SubElement(q, "graderinfo", format="html")
        ET.SubElement(gi, "text").text = ""
        rt = ET.SubElement(q, "responsetemplate", format="html")
        ET.SubElement(rt, "text").text = ""

    xml_bytes = ET.tostring(quiz, encoding="utf-8", xml_declaration=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"lab_{lab.id}_passwords_{timestamp}.xml"
    # Имя файла в кавычках по RFC 6266
    return Response(
        xml_bytes,
        mimetype="application/xml",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )
