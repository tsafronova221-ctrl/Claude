/**
 * АНТИЧИТ — клиентская часть
 *
 * ВАЖНО: вся критическая логика — НА СЕРВЕРЕ.
 *   • Нарушения хранятся в БД; клиент не может их уменьшить.
 *   • Каждый heartbeat проверяется одноразовым nonce-токеном;
 *     поддельный/повторный heartbeat через curl/fetch будет отклонён.
 *   • Если JS отключён — heartbeat_count = 0 в БД → сервер ставит 0 баллов.
 *   • Время проверяется сервером независимо от клиента.
 */
(function () {
    'use strict';

    var CFG = window.ANTICHEAT_CONFIG || {};
    if (!CFG.isTest) return;

    var attemptId        = CFG.attemptId        || 0;
    var durationMin      = CFG.duration         || 0;
    var initialRemaining = (typeof CFG.remainingTime === 'number') ? CFG.remainingTime : null;
    var serverStartMs    = CFG.serverStartMs    || Date.now();
    var csrfToken        = CFG.csrfToken        || '';
    var maxTabViolations = CFG.maxTabViolations || 3;

    // Текущий nonce (ротируется с каждым ответом сервера).
    // Сервер отклонит heartbeat с неверным nonce.
    var currentNonce = CFG.heartbeatNonce || '';

    var HEARTBEAT_MS    = 3000;
    var TAB_DEBOUNCE_MS = 1500;

    var state = {
        tabSwitches:     0,
        copy:            false,
        fullscreenExits: 0,
        timeRemaining:   0,
        timerInterval:   null,
        trackingReady:   true,
        lastViolationMs: 0,
        forceFinishing:  false
    };

    // ══════════════════════════════════════════════════════════════════════
    //  ПОЛНЫЙ ЭКРАН — запрашиваем сразу при загрузке
    // ══════════════════════════════════════════════════════════════════════
    function enterFullscreen() {
        var el = document.documentElement;
        if      (el.requestFullscreen)       el.requestFullscreen().catch(function(){});
        else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
        else if (el.mozRequestFullScreen)    el.mozRequestFullScreen();
        else if (el.msRequestFullscreen)     el.msRequestFullscreen();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', enterFullscreen);
    } else {
        enterFullscreen();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ТАЙМЕР — считается от серверного времени
    // ══════════════════════════════════════════════════════════════════════
    function calcRemaining() {
        if (initialRemaining !== null) {
            return Math.max(0, initialRemaining - Math.floor((Date.now() - serverStartMs) / 1000));
        }
        if (durationMin > 0) {
            return Math.max(0, durationMin * 60 - Math.floor((Date.now() - serverStartMs) / 1000));
        }
        return null;
    }

    function fmt(s) {
        var m = Math.floor(s / 60), sec = s % 60;
        return (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec;
    }

    function updateTimerUI() {
        var box  = document.getElementById('timerBox');
        var span = document.getElementById('timeRemaining');
        if (!box || !span) return;
        box.style.display = 'block';
        span.textContent  = fmt(state.timeRemaining);
        box.classList.toggle('warning', state.timeRemaining <= 60);
    }

    function startTimer() {
        var rem = calcRemaining();
        if (rem === null) return;
        state.timeRemaining = rem;
        updateTimerUI();
        if (rem <= 0) { onForceFinish('time_expired'); return; }

        state.timerInterval = setInterval(function () {
            state.timeRemaining = calcRemaining();
            if (state.timeRemaining === null) { clearInterval(state.timerInterval); return; }
            updateTimerUI();
            if (state.timeRemaining <= 0) onForceFinish('time_expired');
        }, 1000);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ПРИНУДИТЕЛЬНОЕ ЗАВЕРШЕНИЕ — отправляем форму с ответами
    // ══════════════════════════════════════════════════════════════════════
    function onForceFinish(reason) {
        if (state.forceFinishing) return;
        state.forceFinishing = true;

        clearInterval(state.timerInterval);
        clearInterval(heartbeatTimer);

        var msg = reason === 'time_expired'
            ? 'Время вышло!\n\nВаши ответы сохранены и будут проверены автоматически.'
            : 'Работа завершена.\n\nВаши ответы сохранены и будут проверены автоматически.';
        alert(msg);

        var form = document.getElementById('quizForm');
        if (!form) return;

        // Нарушения НЕ передаём — сервер берёт их из БД
        addHidden(form, 'finish_reason', reason);
        form.action = '/auto-finish/' + attemptId;
        form.submit();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  HEARTBEAT — связь с сервером каждые 3 секунды
    //  Отправляет текущий nonce; сервер проверяет его и возвращает новый.
    // ══════════════════════════════════════════════════════════════════════
    function sendHeartbeat() {
        if (state.forceFinishing) return;
        fetch('/anticheat-heartbeat/' + attemptId, {
            method:  'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                t: state.tabSwitches,
                c: state.copy ? 1 : 0,
                f: state.fullscreenExits,
                n: currentNonce          // ← одноразовый токен (обязателен)
            })
        })
        .then(function (r) {
            if (r.status === 403) {
                // Сервер отклонил heartbeat (неверный nonce или сессия)
                onForceFinish('session_invalid');
                return null;
            }
            return r.json();
        })
        .then(function (data) {
            if (!data) return;
            // Обновляем nonce для следующего heartbeat
            if (data.nonce) {
                currentNonce = data.nonce;
            }
            if (data.status === 'force_finish') {
                onForceFinish(data.reason || 'limit_exceeded');
            }
        })
        .catch(function () {
            // Сетевая ошибка — не критично, следующий heartbeat попробует снова
        });
    }

    var heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_MS);
    // Первый heartbeat — сразу, чтобы зарегистрировать nonce на сервере
    sendHeartbeat();

    // ══════════════════════════════════════════════════════════════════════
    //  ПЕРЕКЛЮЧЕНИЕ ВКЛАДОК / ПОТЕРЯ ФОКУСА
    // ══════════════════════════════════════════════════════════════════════
    function registerTabSwitch() {
        if (!state.trackingReady || state.forceFinishing) return;
        var now = Date.now();
        if (now - state.lastViolationMs < TAB_DEBOUNCE_MS) return;

        state.tabSwitches++;
        state.lastViolationMs = now;
        sendHeartbeat();  // немедленно сообщаем серверу

        var left = maxTabViolations - state.tabSwitches;
        if (left <= 0) {
            onForceFinish('limit_exceeded');
        } else {
            showWarning('⚠️ Зафиксировано переключение вкладок / потеря фокуса.');
        }
    }

    document.addEventListener('visibilitychange', function () {
        if (document.hidden) registerTabSwitch();
    });
    window.addEventListener('blur', function () {
        if (!document.hidden) registerTabSwitch();
    });

    // ══════════════════════════════════════════════════════════════════════
    //  КОПИРОВАНИЕ / ВЫРЕЗАНИЕ
    // ══════════════════════════════════════════════════════════════════════
    document.addEventListener('copy', function () {
        if (!state.trackingReady || state.copy) return;
        state.copy = true;
        showWarning('⚠️ Зафиксировано копирование текста.');
        sendHeartbeat();
    });
    document.addEventListener('cut', function () {
        if (!state.trackingReady || state.copy) return;
        state.copy = true;
        showWarning('⚠️ Зафиксировано вырезание текста.');
        sendHeartbeat();
    });

    // ══════════════════════════════════════════════════════════════════════
    //  ПОЛНОЭКРАННЫЙ РЕЖИМ
    // ══════════════════════════════════════════════════════════════════════
    function onFsChange() {
        var inFs = !!(
            document.fullscreenElement || document.webkitFullscreenElement ||
            document.mozFullScreenElement || document.msFullscreenElement
        );
        if (!inFs && state.trackingReady && !state.forceFinishing) {
            var now = Date.now();
            if (now - state.lastViolationMs >= TAB_DEBOUNCE_MS) {
                state.fullscreenExits++;
                state.lastViolationMs = now;
                sendHeartbeat();
                showWarning('⚠️ Зафиксирован выход из полноэкранного режима.');
            }
        }
    }
    document.addEventListener('fullscreenchange',       onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    document.addEventListener('mozfullscreenchange',    onFsChange);
    document.addEventListener('MSFullscreenChange',     onFsChange);

    // ══════════════════════════════════════════════════════════════════════
    //  БЛОКИРОВКА ГОРЯЧИХ КЛАВИШ
    // ══════════════════════════════════════════════════════════════════════
    document.addEventListener('keydown', function (e) {
        var k    = (e.key || '').toLowerCase();
        var ctrl = e.ctrlKey || e.metaKey;
        var blocked =
            k === 'f12' ||
            (ctrl && e.shiftKey && (k === 'i' || k === 'j' || k === 'c')) ||
            (ctrl && (k === 'u' || k === 's' || k === 'p')) ||
            k === 'printscreen' ||
            (e.metaKey && e.shiftKey && (k === '3' || k === '4' || k === '5' || k === 's'));
        if (blocked) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, true);

    // ══════════════════════════════════════════════════════════════════════
    //  ЗАПРЕТ КОНТЕКСТНОГО МЕНЮ И ВЫДЕЛЕНИЯ
    // ══════════════════════════════════════════════════════════════════════
    document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    document.body.style.userSelect       = 'none';
    document.body.style.webkitUserSelect = 'none';

    // ══════════════════════════════════════════════════════════════════════
    //  ПЕЧАТЬ
    // ══════════════════════════════════════════════════════════════════════
    window.addEventListener('beforeprint', function () {
        if (!state.forceFinishing) {
            state.tabSwitches++;
            sendHeartbeat();
        }
    });

    // ══════════════════════════════════════════════════════════════════════
    //  ЗАЩИТА ОТ УХОДА СО СТРАНИЦЫ
    // ══════════════════════════════════════════════════════════════════════
    window.addEventListener('beforeunload', function (e) {
        if (state.trackingReady && !state.forceFinishing && state.timeRemaining > 0) {
            var msg = 'Вы уверены? Незавершённая работа может быть потеряна.';
            e.returnValue = msg;
            return msg;
        }
    });

    // ══════════════════════════════════════════════════════════════════════
    //  ФОРМА — добавляем reason при обычной сдаче (нарушения не передаём)
    // ══════════════════════════════════════════════════════════════════════
    var form = document.getElementById('quizForm');
    if (form) {
        form.addEventListener('submit', function () {
            if (state.forceFinishing) return;
            addHidden(form, 'finish_reason', 'manual');
            clearInterval(state.timerInterval);
            clearInterval(heartbeatTimer);
        }, true);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  UI ХЕЛПЕРЫ
    // ══════════════════════════════════════════════════════════════════════
    var _warnTimer = null;
    function showWarning(msg) {
        var panel = document.getElementById('warningBanner');
        if (!panel) return;
        panel.textContent   = msg;
        panel.style.display = 'block';
        panel.style.opacity = '1';
        clearTimeout(_warnTimer);
        _warnTimer = setTimeout(function () {
            panel.style.opacity = '0';
            setTimeout(function () { panel.style.display = 'none'; }, 500);
        }, 4000);
    }

    function addHidden(form, name, value) {
        var old = form.querySelector('input[name="' + name + '"]');
        if (old) old.parentNode.removeChild(old);
        var el   = document.createElement('input');
        el.type  = 'hidden';
        el.name  = name;
        el.value = String(value);
        form.appendChild(el);
    }

    // ── Старт ──────────────────────────────────────────────────────────
    startTimer();

}());
