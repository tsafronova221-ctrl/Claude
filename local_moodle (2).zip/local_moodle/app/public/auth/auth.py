import os
import sys
import bcrypt

from flask import render_template, request, redirect, url_for
from flask_login import login_user, logout_user, login_required, UserMixin

from .__blueprint__ import auth_bp
from app.csrf import validate_csrf_token
from app import login_manager


def _load_bcrypt_hash(env_key: str) -> str:
    """
    Загружает bcrypt-хеш из переменной среды.
    Завершает приложение, если переменная не задана или содержит значение-заглушку.
    """
    h = os.environ.get(env_key, '').strip()
    if not h or h.startswith('$2b$12$ЗАМЕНИТЕ') or h.startswith('HASH_OF'):
        print(
            f"\n{'='*60}\n"
            f"FATAL: {env_key} не задан или содержит значение-заглушку.\n"
            f"  Сгенерируйте хеш:\n"
            f"  python -c \"import bcrypt; print(bcrypt.hashpw(b'ваш_пароль', bcrypt.gensalt()).decode())\"\n"
            f"{'='*60}\n",
            file=sys.stderr,
        )
        sys.exit(1)
    if not h.startswith('$2'):
        print(
            f"\n{'='*60}\n"
            f"FATAL: {env_key} должен быть bcrypt-хешем (начинается с $2b$...).\n"
            f"  Сгенерируйте хеш:\n"
            f"  python -c \"import bcrypt; print(bcrypt.hashpw(b'ваш_пароль', bcrypt.gensalt()).decode())\"\n"
            f"{'='*60}\n",
            file=sys.stderr,
        )
        sys.exit(1)
    return h


_ADMIN_HASH = _load_bcrypt_hash('ADMIN_PASSWORD_HASH')
_TEACHER_HASH = _load_bcrypt_hash('TEACHER_PASSWORD_HASH')

USERS: dict[str, str] = {
    "admin": _ADMIN_HASH,
    "teacher": _TEACHER_HASH,
}


class SimpleUser(UserMixin):
    def __init__(self, username):
        self.id = username


def _verify(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not validate_csrf_token():
            from flask import abort
            abort(403)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        stored = USERS.get(username)
        if stored and _verify(password, stored):
            user = SimpleUser(username)
            login_user(user)
            return redirect(url_for("admin.index"))

        return render_template("admin/login.html", error="Неверный логин или пароль")

    return render_template("admin/login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
