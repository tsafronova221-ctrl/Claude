"""
Публичные маршруты — логика тестирования.

АРХИТЕКТУРА АНТИЧИТА:
──────────────────────────────────────────────────────────────────────────────
• Все нарушения хранятся ТОЛЬКО в БД. Клиент не может их изменить напрямую.
• Нарушения обновляются ТОЛЬКО через /anticheat-heartbeat.
  /finish и /auto-finish ИГНОРИРУЮТ поля нарушений из формы.
• Каждый heartbeat защищён одноразовым nonce-токеном (ротация при каждом
  успешном ответе), что исключает подделку heartbeat через curl / fetch.
• /finish принудительно проверяет время на сервере.
• /finish требует как минимум одного heartbeat для тестов с ограничением
  времени (иначе JS был отключён → score = 0).
──────────────────────────────────────────────────────────────────────────────
"""
import random
import secrets as _secrets

from flask import (
    Blueprint, render_template, request, redirect, url_for,
    jsonify, session, abort
)
from app import db
from app.models import (
    Student, Group, Lab, LabFile, Question,
    Attempt, Answer, LabPassword, FileQuestionAnswer,
)
from app.security import generate_watermark_hash
from app.csrf import generate_csrf_token, validate_csrf_token
from datetime import datetime
import pytz

MSK = pytz.timezone('Europe/Moscow')
public_bp = Blueprint("public", __name__)

# Максимум переключений вкладок до принудительного завершения
MAX_TAB_VIOLATIONS = 3

# Максимальный допустимый разрыв между heartbeat-ами (секунды).
# HEARTBEAT_MS на клиенте = 3000 мс. 15 секунд = 5 пропущенных heartbeat подряд.
MAX_HEARTBEAT_GAP_SEC = 15


def _localize(dt):
    if dt is None:
        return None
    return MSK.localize(dt) if dt.tzinfo is None else dt


def _check_time_expired(attempt, lab):
    """Серверная проверка времени. Возвращает (истекло, остаток_секунд)."""
    if not lab.is_test or not lab.test_duration or lab.test_duration <= 0:
        return False, None
    now       = datetime.now(MSK)
    started   = _localize(attempt.started_at)
    elapsed   = (now - started).total_seconds()
    max_s     = lab.test_duration * 60
    remaining = int(max_s - elapsed)
    return remaining <= 0, max(0, remaining)


def _ordered_questions(attempt):
    question_map = {a.question_id: a.question for a in attempt.answers}
    return [question_map[a.question_id] for a in attempt.answers
            if a.question_id in question_map]


def _grade_answers(attempt, form_data):
    """
    Считывает ответы из form_data, проверяет и сохраняет в БД.
    Возвращает (score, results_list).
    НАРУШЕНИЯ НЕ ТРОГАЕТ — они управляются только через heartbeat.
    """
    lab_file_id = attempt.password.file_id
    correct_map = {
        fqa.question_id: fqa.correct_answer
        for fqa in FileQuestionAnswer.query.filter_by(lab_file_id=lab_file_id)
    }
    score   = 0
    results = []
    for ans_rec in attempt.answers:
        q          = ans_rec.question
        ans_text   = form_data.get(f"q{q.id}", "").strip()
        correct    = (correct_map.get(q.id) or "").strip()
        is_correct = ans_text.lower() == correct.lower()
        if is_correct:
            score += 1
        results.append(['neutral', q.text])
        ans_rec.answer_text = ans_text
        ans_rec.is_correct  = is_correct
    return score, results


def _new_nonce() -> str:
    return _secrets.token_hex(32)


def _zero_score_finish(attempt, reason: str):
    """Закрывает попытку с нулём и коммитит."""
    attempt.score          = 0
    attempt.finished_at    = datetime.now(MSK)
    attempt.watermark_hash = generate_watermark_hash(attempt)
    db.session.commit()
    session.pop('active_attempt_id', None)
    return render_template(
        "public/finish.html", attempt=attempt,
        answers=[['neutral', a.question.text] for a in attempt.answers],
        zero_reason=reason,
    )


# ─────────────────────────────────────────────────────────────────────────────
# HEARTBEAT — единственное место, где обновляются нарушения
# ─────────────────────────────────────────────────────────────────────────────
@public_bp.route("/anticheat-heartbeat/<int:attempt_id>", methods=["POST"])
def anticheat_heartbeat(attempt_id):
    # 1. Проверяем сессию
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)

    # 2. Уже завершена?
    if attempt.finished_at is not None:
        return jsonify({'status': 'already_finished'})

    # 3. Серверная проверка времени
    expired, remaining = _check_time_expired(attempt, attempt.lab)
    if expired:
        return jsonify({'status': 'force_finish', 'reason': 'time_expired'})

    data = request.get_json() or {}

    # 4. Проверка nonce (одноразового токена)
    #    Первый heartbeat (heartbeat_count == 0) получает начальный nonce,
    #    который был выдан сервером при старте попытки.
    #    Все последующие обязаны возвращать токен из предыдущего ответа.
    if attempt.heartbeat_nonce:
        client_nonce = data.get('n', '')
        if client_nonce != attempt.heartbeat_nonce:
            # Поддельный или устаревший heartbeat — отклоняем без ответа
            abort(403)

    # 5. Обновляем нарушения ТОЛЬКО на сервере (клиент не может уменьшить счётчики)
    if attempt.lab.is_test:
        attempt.violation_tab_switch = max(
            attempt.violation_tab_switch or 0, int(data.get('t', 0))
        )
        attempt.violation_copy = attempt.violation_copy or (int(data.get('c', 0)) == 1)
        attempt.violation_fullscreen_exit = max(
            attempt.violation_fullscreen_exit or 0, int(data.get('f', 0))
        )

    # 6. Обновляем heartbeat-статистику
    attempt.heartbeat_count   = (attempt.heartbeat_count or 0) + 1
    attempt.last_heartbeat_at = datetime.now(MSK)

    # 7. Ротируем nonce — следующий heartbeat обязан вернуть этот токен
    new_nonce             = _new_nonce()
    attempt.heartbeat_nonce = new_nonce

    db.session.commit()

    # 8. Лимит нарушений — просим клиент сабмитить форму через /auto-finish
    if attempt.lab.is_test and (attempt.violation_tab_switch or 0) >= MAX_TAB_VIOLATIONS:
        return jsonify({'status': 'force_finish', 'reason': 'too_many_tab_switches'})

    return jsonify({
        'status':           'ok',
        'remaining':        remaining,
        'nonce':            new_nonce,   # клиент ОБЯЗАН вернуть в следующем heartbeat
    })


# ─────────────────────────────────────────────────────────────────────────────
# INDEX
# ─────────────────────────────────────────────────────────────────────────────
@public_bp.route("/")
def index():
    groups = Group.query.all()
    return render_template("public/index.html", groups=groups,
                           csrf_token=generate_csrf_token())


# ─────────────────────────────────────────────────────────────────────────────
# START — создаёт или восстанавливает попытку
# ─────────────────────────────────────────────────────────────────────────────
@public_bp.route("/start", methods=["POST"])
def start():
    if not validate_csrf_token():
        abort(403)

    last     = request.form.get("last_name",  "").strip()
    first    = request.form.get("first_name", "").strip()
    group_id = request.form.get("group_id",   "").strip()
    password = request.form.get("password",   "").strip().upper()

    all_groups = Group.query.all()

    def err(msg):
        return render_template("public/index.html", groups=all_groups,
                               error=msg, csrf_token=generate_csrf_token())

    if not last or not first or not password:
        return err("Заполните все поля")

    lp = LabPassword.query.filter_by(password=password).first()
    if not lp:
        return err("Неверный пароль варианта")

    lab = Lab.query.get(lp.lab_id)

    if group_id:
        try:
            gid = int(group_id)
        except ValueError:
            abort(400)
        if gid not in [g.id for g in lab.groups]:
            return err("Эта работа недоступна для выбранной группы")

    now = datetime.now(MSK)
    if _localize(lab.start_at) and _localize(lab.start_at) > now:
        return err("Время выполнения работы ещё не наступило")
    if _localize(lab.deadline_at) and now > _localize(lab.deadline_at):
        return err("Срок сдачи работы истёк")

    sq = Student.query.filter_by(last_name=last, first_name=first)
    if group_id:
        sq = sq.filter_by(group_id=int(group_id))
    student = sq.first()
    if not student:
        student = Student(last_name=last, first_name=first,
                          group_id=int(group_id) if group_id else None)
        db.session.add(student)
        db.session.commit()

    existing = Attempt.query.filter_by(
        student_id=student.id, lab_id=lab.id, password_id=lp.id
    ).first()

    if existing:
        if existing.finished_at is not None:
            return err("Вы уже выполняли эту работу. Повторная попытка невозможна.")

        started = _localize(existing.started_at)
        if (now - started).total_seconds() > 24 * 3600:
            db.session.delete(existing)
            db.session.commit()
            existing = None
        else:
            expired, remaining = _check_time_expired(existing, lab)
            if expired:
                existing.finished_at    = now
                existing.score          = 0
                existing.watermark_hash = generate_watermark_hash(existing)
                db.session.commit()
                return err("Время на выполнение работы истекло. Повторная попытка невозможна.")

            if (lab.is_test and
                    (existing.violation_tab_switch or 0) >= MAX_TAB_VIOLATIONS
                    and existing.finished_at is None):
                existing.finished_at    = now
                existing.score          = 0
                existing.watermark_hash = generate_watermark_hash(existing)
                db.session.commit()
                return err("Попытка завершена из-за нарушений. Повторная попытка невозможна.")

            lab_file  = LabFile.query.get(lp.file_id)
            questions = _ordered_questions(existing)
            session['active_attempt_id'] = existing.id
            kwargs = dict(
                attempt=existing, lab_file=lab_file,
                questions=questions, lab=lab,
                csrf_token=generate_csrf_token(),
                max_tab_violations=MAX_TAB_VIOLATIONS,
                heartbeat_nonce=existing.heartbeat_nonce or '',
            )
            if remaining is not None:
                kwargs['remaining_time'] = remaining
            return render_template("public/questions.html", **kwargs)

    # ── Новая попытка ──────────────────────────────────────────────────────
    lab_file = LabFile.query.get(lp.file_id)

    # Начальный nonce — будет отправлен клиенту и проверен при первом heartbeat
    initial_nonce = _new_nonce()

    attempt = Attempt(
        student_id=student.id,
        lab_id=lab.id,
        password_id=lp.id,
        ip=request.remote_addr,
        user_agent=request.headers.get("User-Agent", "")[:256],
        started_at=datetime.now(MSK),
        heartbeat_count=0,
        heartbeat_nonce=initial_nonce,
    )
    db.session.add(attempt)
    db.session.flush()

    all_q = Question.query.filter_by(lab_id=lab.id).all()
    if lab.is_test and lab.questions_count and lab.questions_count > 0:
        selected = random.sample(all_q, min(len(all_q), lab.questions_count))
    else:
        selected = all_q

    for q in selected:
        db.session.add(Answer(attempt_id=attempt.id, question_id=q.id,
                              answer_text="", is_correct=False))
    db.session.commit()

    session['active_attempt_id'] = attempt.id

    kwargs = dict(
        attempt=attempt, lab_file=lab_file,
        questions=selected, lab=lab,
        csrf_token=generate_csrf_token(),
        max_tab_violations=MAX_TAB_VIOLATIONS,
        heartbeat_nonce=initial_nonce,
    )
    if lab.is_test and lab.test_duration:
        kwargs['remaining_time'] = lab.test_duration * 60
    return render_template("public/questions.html", **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# FINISH — обычная сдача студентом
# ─────────────────────────────────────────────────────────────────────────────
@public_bp.route("/finish/<int:attempt_id>", methods=["POST"])
def finish(attempt_id):
    if not validate_csrf_token():
        abort(403)
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)

    # Уже завершена — показываем результат
    if attempt.finished_at is not None:
        results = [['neutral', a.question.text] for a in attempt.answers]
        return render_template("public/finish.html", attempt=attempt, answers=results)

    # ── 1. Серверная проверка времени ─────────────────────────────────────
    expired, _ = _check_time_expired(attempt, attempt.lab)
    if expired:
        return _zero_score_finish(attempt, 'time_expired')

    # ── 2. Проверка наличия heartbeat-ов (для тестов с таймером) ──────────
    # Если heartbeat_count == 0 и работа является тестом с таймером,
    # значит JavaScript был отключён — ни одного heartbeat не поступило.
    if (attempt.lab.is_test
            and attempt.lab.test_duration
            and attempt.lab.test_duration > 0
            and (attempt.heartbeat_count or 0) == 0):
        return _zero_score_finish(attempt, 'no_heartbeat')

    # ── 3. Проверка свежести последнего heartbeat ─────────────────────────
    # Если последний heartbeat был давно → JS был отключён в процессе работы
    if (attempt.lab.is_test
            and attempt.last_heartbeat_at is not None):
        last_hb = _localize(attempt.last_heartbeat_at)
        gap = (datetime.now(MSK) - last_hb).total_seconds()
        if gap > MAX_HEARTBEAT_GAP_SEC:
            return _zero_score_finish(attempt, 'heartbeat_gap')

    # ── 4. Принудительное завершение при превышении нарушений ────────────
    if (attempt.lab.is_test
            and (attempt.violation_tab_switch or 0) >= MAX_TAB_VIOLATIONS):
        return _zero_score_finish(attempt, 'too_many_violations')

    # ── 5. Сохраняем ответы (нарушения не трогаем — они уже в БД) ─────────
    score, results = _grade_answers(attempt, request.form)
    attempt.score          = score
    attempt.finished_at    = datetime.now(MSK)
    attempt.watermark_hash = generate_watermark_hash(attempt)
    db.session.commit()

    session.pop('active_attempt_id', None)
    return render_template("public/finish.html", attempt=attempt, answers=results)


# ─────────────────────────────────────────────────────────────────────────────
# AUTO-FINISH — завершение по таймеру или нарушениям (инициировано клиентом)
# ─────────────────────────────────────────────────────────────────────────────
@public_bp.route("/auto-finish/<int:attempt_id>", methods=["POST"])
def auto_finish(attempt_id):
    if not validate_csrf_token():
        abort(403)
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)

    if attempt.finished_at is not None:
        results = [['neutral', a.question.text] for a in attempt.answers]
        return render_template("public/finish.html", attempt=attempt, answers=results)

    # Нарушения уже в БД (из heartbeat). Просто сохраняем ответы.
    score, results = _grade_answers(attempt, request.form)
    attempt.score          = score
    attempt.finished_at    = datetime.now(MSK)
    attempt.watermark_hash = generate_watermark_hash(attempt)
    db.session.commit()

    session.pop('active_attempt_id', None)
    return render_template("public/finish.html", attempt=attempt, answers=results)
