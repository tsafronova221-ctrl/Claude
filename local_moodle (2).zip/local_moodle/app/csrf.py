"""
Simple CSRF protection using Flask sessions.
Tokens are stored in the session (signed by Flask's SECRET_KEY).
"""
import secrets
from functools import wraps
from flask import session, request, abort


def generate_csrf_token() -> str:
    """Generate (or reuse) a CSRF token stored in the current session."""
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']


def validate_csrf_token() -> bool:
    """Return True if the submitted CSRF token matches the session token."""
    session_token = session.get('_csrf_token')
    if not session_token:
        return False
    # Accept from form field or custom header (for fetch/XHR)
    submitted = request.form.get('_csrf_token') or request.headers.get('X-CSRF-Token')
    if not submitted:
        return False
    return secrets.compare_digest(session_token, submitted)


def csrf_required(f):
    """Decorator: abort 403 if CSRF token is missing or wrong on POST requests."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
            if not validate_csrf_token():
                abort(403)
        return f(*args, **kwargs)
    return decorated
