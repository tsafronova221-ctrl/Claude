import hashlib
import bcrypt
from config import Config


def hash_password(plain: str) -> str:
    """Хеширование пароля через bcrypt."""
    return bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    """Проверка пароля по bcrypt-хешу."""
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


def generate_watermark_hash(attempt) -> str:
    """Генерация хеша-водяного знака для попытки (полный SHA-256, без усечения)."""
    lab_or_prot = attempt.lab_id if hasattr(attempt, 'lab_id') else attempt.protection_id
    data = (
        f"{Config.SECRET_KEY}|{attempt.id}|{attempt.student_id}"
        f"|{lab_or_prot}|{attempt.score}|{attempt.finished_at}"
    )
    return hashlib.sha256(data.encode()).hexdigest()  # 64 символа, без [:24]
