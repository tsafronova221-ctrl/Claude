﻿# -*- coding: utf-8 -*-
import os
import time
import threading
from collections import defaultdict

from flask import Flask, redirect, url_for, send_file, request, abort
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager, current_user, UserMixin

login_manager = LoginManager()
db = SQLAlchemy()
migrate = Migrate()

# ── Простой in-memory rate limiter ───────────────────────────────────────────
_rate_lock   = threading.Lock()
_rate_store  = defaultdict(list)   # key -> [timestamp, ...]

def _is_rate_limited(key: str, max_calls: int, window_sec: int) -> bool:
    """Возвращает True если лимит превышен (скользящее окно)."""
    now = time.monotonic()
    with _rate_lock:
        calls = _rate_store[key]
        _rate_store[key] = [t for t in calls if now - t < window_sec]
        if len(_rate_store[key]) >= max_calls:
            return True
        _rate_store[key].append(now)
        return False
# ─────────────────────────────────────────────────────────────────────────────


@login_manager.user_loader
def load_user(username):
    """Загрузчик пользователя для Flask-Login"""
    from .public.auth.auth import USERS, SimpleUser
    if username in USERS:
        return SimpleUser(username)
    return None


def create_app():
    app = Flask(__name__, instance_relative_config=True,
                template_folder='templates',
                static_folder='static')
    app.config.from_object("config.Config")

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .public.routes import public_bp
    from .public.auth import auth_bp
    from .admin import admin_bp

    # ── CSRF global ──────────────────────────────────────────────
    from .csrf import generate_csrf_token
    app.jinja_env.globals['csrf_token'] = generate_csrf_token
    # ─────────────────────────────────────────────────────────────

    @admin_bp.before_request
    def before_request():
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login"))

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # ── Secure file download route ────────────────────────────────
    @app.route('/lab-file/<int:file_id>')
    def lab_file_download(file_id):
        """Serve lab files with path-traversal protection."""
        from app.models import LabFile
        lf = LabFile.query.get_or_404(file_id)

        base      = os.path.abspath(os.path.dirname(app.root_path))
        full_path = os.path.abspath(os.path.join(base, lf.file_path))
        labs_dir  = os.path.abspath(os.path.join(base, 'instance', 'labs'))

        if not full_path.startswith(labs_dir + os.sep) and full_path != labs_dir:
            abort(403)

        if not os.path.isfile(full_path):
            abort(404)

        return send_file(full_path, as_attachment=True)
    # ─────────────────────────────────────────────────────────────

    # ── Security headers (включая CSP) ───────────────────────────
    @app.after_request
    def set_security_headers(response):
        response.headers['X-Content-Type-Options']  = 'nosniff'
        response.headers['X-Frame-Options']         = 'DENY'
        response.headers['X-XSS-Protection']        = '1; mode=block'
        response.headers['Referrer-Policy']         = 'strict-origin-when-cross-origin'
        # ИСПРАВЛЕНО: добавлен Content-Security-Policy
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "font-src 'self'; "
            "connect-src 'self'; "
            "frame-ancestors 'none';"
        )
        return response
    # ─────────────────────────────────────────────────────────────

    # ── IP whitelist ──────────────────────────────────────────────
    import ipaddress

    ALLOWED_NETWORKS = [
        ipaddress.ip_network('10.24.182.0/24'),
    ]
    ALLOWED_IPS = {
        '10.22.11.195', '10.22.11.178',
 '10.24.182.149'   }

    # ИСПРАВЛЕНО: X-Forwarded-For принимается ТОЛЬКО от доверенных прокси
    # Раньше любой клиент мог прислать X-Forwarded-For: 10.24.182.1
    # и полностью обходил IP-белый список.
    TRUSTED_PROXIES = {'127.0.0.1', '::1'}

    @app.before_request
    def check_ip():
        real_ip = request.remote_addr

        # Заголовок X-Forwarded-For доверяем ТОЛЬКО если запрос пришёл от нашего прокси
        if real_ip in TRUSTED_PROXIES:
            forwarded = request.headers.get('X-Forwarded-For')
            if forwarded:
                real_ip = forwarded.split(',')[0].strip()

        try:
            addr = ipaddress.ip_address(real_ip)
        except ValueError:
            abort(403)

        if real_ip in ALLOWED_IPS:
            return

        for net in ALLOWED_NETWORKS:
            if addr in net:
                return

        abort(403)
    # ─────────────────────────────────────────────────────────────

    # ── Rate limiter для /login ───────────────────────────────────
    # ИСПРАВЛЕНО: защита от брутфорса — max 10 попыток за 60 секунд с IP
    @app.before_request
    def login_rate_limit():
        if request.path == '/login' and request.method == 'POST':
            ip = request.remote_addr
            if _is_rate_limited(f'login:{ip}', max_calls=10, window_sec=60):
                abort(429)
    # ─────────────────────────────────────────────────────────────

    # ── Rate limiter для /start ───────────────────────────────────
    # ИСПРАВЛЕНО: защита от перебора паролей вариантов — max 15 за 60 сек с IP
    @app.before_request
    def start_rate_limit():
        if request.path == '/start' and request.method == 'POST':
            ip = request.remote_addr
            if _is_rate_limited(f'start:{ip}', max_calls=15, window_sec=60):
                abort(429)
    # ─────────────────────────────────────────────────────────────

    return app
