﻿#!/usr/bin/env python3
"""
Скрипт для создания 200 теоретических вопросов по анализу ELF файлов через hex
и защиты для 9 лабораторной работы.
"""

import sqlite3
import os
import struct
from datetime import datetime

DB_PATH = 'instance/app.db'
LABS_DIR = 'instance/labs'
PROTECTIONS_DIR = 'instance/protections'

# 200 теоретических вопросов по ELF файлам с ответами (число или слово на англ.)
THEORY_QUESTIONS = [
    # ==================== 1. MAGIC / e_ident (Вопросы 1-20) ====================
    ("Какие первые 4 байта (magic number) идентифицируют ELF-файл?", "7f454c46"),
    ("Какой байт ELF magic number соответствует символу 'E'?", "0x45"),
    ("Какой байт ELF magic number соответствует символу 'L'?", "0x4c"),
    ("Какой байт ELF magic number соответствует символу 'F'?", "0x46"),
    ("Какой индекс (e_ident) хранит класс файла (32/64-bit)? (EI_CLASS)", "4"),
    ("Какое значение EI_CLASS означает 32-битный ELF?", "1"),
    ("Какое значение EI_CLASS означает 64-битный ELF?", "2"),
    ("Какой индекс e_ident хранит порядок байт? (EI_DATA)", "5"),
    ("Какое значение EI_DATA означает little-endian?", "1"),
    ("Какое значение EI_DATA означает big-endian?", "2"),
    ("Какой индекс хранит версию ELF? (EI_VERSION)", "6"),
    ("Какое текущее значение EI_VERSION?", "1"),
    ("Какой индекс хранит OS/ABI? (EI_OSABI)", "7"),
    ("Какое значение EI_OSABI соответствует ELFOSABI_NONE (System V)?", "0"),
    ("Какой индекс хранит ABI version? (EI_ABIVERSION)", "8"),
    ("Сколько байт занимает поле e_ident?", "16"),
    ("Какое значение EI_OSABI соответствует Linux?", "3"),
    ("Какой индекс является первым padding байтом в e_ident?", "9"),
    ("Сколько padding байт в e_ident начиная с индекса 9?", "7"),
    ("Каков ASCII-код первого байта ELF (0x7f)?", "127"),

    # ==================== 2. ELF HEADER (Вопросы 21-50) ====================
    ("Какой тип данных хранит e_type в ELF64?", "Elf64_Half"),
    ("Какое значение e_type соответствует ET_EXEC (исполняемый файл)?", "2"),
    ("Какое значение e_type соответствует ET_DYN (разделяемый объект)?", "3"),
    ("Какое значение e_type соответствует ET_REL (relocatable)?", "1"),
    ("Какое значение e_type соответствует ET_CORE?", "4"),
    ("Какое значение e_type соответствует ET_NONE?", "0"),
    ("Какой размер ELF-заголовка для 32-bit ELF (e_ehsize)?", "52"),
    ("Какой размер ELF-заголовка для 64-bit ELF (e_ehsize)?", "64"),
    ("Какое поле хранит адрес точки входа программы?", "e_entry"),
    ("Какое поле хранит смещение таблицы программных заголовков?", "e_phoff"),
    ("Какое поле хранит смещение таблицы секций?", "e_shoff"),
    ("Какое поле хранит флаги, зависящие от архитектуры?", "e_flags"),
    ("Какое поле хранит размер одной записи в таблице программных заголовков?", "e_phentsize"),
    ("Какое поле хранит количество записей в таблице программных заголовков?", "e_phnum"),
    ("Какое поле хранит размер одной записи в таблице секций?", "e_shentsize"),
    ("Какое поле хранит количество секций?", "e_shnum"),
    ("Какое поле хранит индекс секции с именами секций?", "e_shstrndx"),
    ("Какой размер записи в таблице секций для 64-bit ELF?", "64"),
    ("Какой размер записи в таблице программных заголовков для 64-bit ELF?", "56"),
    ("Какой размер записи в таблице программных заголовков для 32-bit ELF?", "32"),
    ("Какое поле хранит машинную архитектуру?", "e_machine"),
    ("Какое значение e_machine для x86 (EM_386)?", "3"),
    ("Какое значение e_machine для x86-64 (EM_X86_64)?", "62"),
    ("Какое значение e_machine для ARM (EM_ARM)?", "40"),
    ("Какое значение e_machine для AArch64 (EM_AARCH64)?", "183"),
    ("Какое значение e_machine для MIPS (EM_MIPS)?", "8"),
    ("Какое значение e_machine для RISC-V (EM_RISCV)?", "243"),
    ("Какое значение e_machine для PowerPC (EM_PPC)?", "20"),
    ("Что означает e_phoff равный 0?", "nosegments"),
    ("Что означает e_shoff равный 0?", "nosections"),

    # ==================== 3. SECTION HEADERS (Вопросы 51-90) ====================
    ("Какое поле заголовка секции хранит тип секции?", "sh_type"),
    ("Какое значение sh_type соответствует SHT_NULL?", "0"),
    ("Какое значение sh_type соответствует SHT_PROGBITS?", "1"),
    ("Какое значение sh_type соответствует SHT_SYMTAB?", "2"),
    ("Какое значение sh_type соответствует SHT_STRTAB?", "3"),
    ("Какое значение sh_type соответствует SHT_RELA?", "4"),
    ("Какое значение sh_type соответствует SHT_HASH?", "5"),
    ("Какое значение sh_type соответствует SHT_DYNAMIC?", "6"),
    ("Какое значение sh_type соответствует SHT_NOTE?", "7"),
    ("Какое значение sh_type соответствует SHT_NOBITS?", "8"),
    ("Какое значение sh_type соответствует SHT_REL?", "9"),
    ("Какое значение sh_type соответствует SHT_DYNSYM?", "11"),
    ("Какой флаг секции соответствует SHF_WRITE?", "0x1"),
    ("Какой флаг секции соответствует SHF_ALLOC?", "0x2"),
    ("Какой флаг секции соответствует SHF_EXECINSTR?", "0x4"),
    ("Какой флаг секции соответствует SHF_MERGE?", "0x10"),
    ("Какой флаг секции соответствует SHF_STRINGS?", "0x20"),
    ("Какой флаг секции соответствует SHF_LINK_ORDER?", "0x80"),
    ("Какое поле заголовка секции хранит смещение в файле?", "sh_offset"),
    ("Какое поле заголовка секции хранит размер секции?", "sh_size"),
    ("Какое поле хранит выравнивание секции?", "sh_addralign"),
    ("Какое поле хранит виртуальный адрес секции?", "sh_addr"),
    ("Какое поле хранит имя секции (индекс в strtab)?", "sh_name"),
    ("Какой индекс всегда является первой (null) секцией?", "0"),
    ("Как называется секция, содержащая имена всех секций?", ".shstrtab"),
    ("Как называется секция, содержащая таблицу символов?", ".symtab"),
    ("Как называется секция со строками для .symtab?", ".strtab"),
    ("Как называется секция с динамическими символами?", ".dynsym"),
    ("Как называется секция с динамическими строками?", ".dynstr"),
    ("Как называется секция с кодом программы?", ".text"),
    ("Как называется секция с инициализированными данными?", ".data"),
    ("Как называется секция с неинициализированными данными?", ".bss"),
    ("Как называется секция с read-only данными?", ".rodata"),
    ("Как называется секция с динамической линковкой?", ".dynamic"),
    ("Как называется секция с записями перемещений с addend?", ".rela.text"),
    ("Как называется секция, хранящая PLT (таблицу переходов)?", ".plt"),
    ("Как называется секция с глобальной таблицей смещений?", ".got"),
    ("Какой тип у секции .bss?", "SHT_NOBITS"),
    ("Какое значение sh_entsize для записи таблицы символов в 64-bit ELF?", "24"),
    ("Какое значение sh_type соответствует SHT_GNU_HASH?", "0x6ffffff6"),

    # ==================== 4. PROGRAM HEADERS / SEGMENTS (Вопросы 91-115) ====================
    ("Какое поле заголовка программного сегмента хранит тип?", "p_type"),
    ("Какое значение p_type соответствует PT_NULL?", "0"),
    ("Какое значение p_type соответствует PT_LOAD?", "1"),
    ("Какое значение p_type соответствует PT_DYNAMIC?", "2"),
    ("Какое значение p_type соответствует PT_INTERP?", "3"),
    ("Какое значение p_type соответствует PT_NOTE?", "4"),
    ("Какое значение p_type соответствует PT_PHDR?", "6"),
    ("Какое значение p_type соответствует PT_TLS?", "7"),
    ("Какой флаг сегмента означает execute? (PF_X)", "0x1"),
    ("Какой флаг сегмента означает write? (PF_W)", "0x2"),
    ("Какой флаг сегмента означает read? (PF_R)", "0x4"),
    ("Какое поле хранит смещение сегмента в файле?", "p_offset"),
    ("Какое поле хранит виртуальный адрес сегмента?", "p_vaddr"),
    ("Какое поле хранит физический адрес сегмента?", "p_paddr"),
    ("Какое поле хранит размер сегмента в файле?", "p_filesz"),
    ("Какое поле хранит размер сегмента в памяти?", "p_memsz"),
    ("Какое поле хранит выравнивание сегмента?", "p_align"),
    ("Какое поле хранит флаги сегмента в 64-bit ELF?", "p_flags"),
    ("Что означают флаги сегмента 0x5 (PF_R | PF_X)?", "read-execute"),
    ("Что означают флаги сегмента 0x6 (PF_R | PF_W)?", "read-write"),
    ("Какое значение p_type для GNU_STACK?", "0x6474e551"),
    ("Какое значение p_type для GNU_EH_FRAME?", "0x6474e550"),
    ("Какое значение p_type для GNU_RELRO?", "0x6474e552"),
    ("Какой тип сегмента содержит путь к динамическому линкеру?", "PT_INTERP"),
    ("Какое минимальное выравнивание PT_LOAD сегментов (в байтах, стандартный размер страницы)?", "4096"),

    # ==================== 5. СИМВОЛЫ / SYMBOL TABLE (Вопросы 116-140) ====================
    ("Сколько байт занимает запись Elf64_Sym?", "24"),
    ("Сколько байт занимает запись Elf32_Sym?", "16"),
    ("Какое поле Elf64_Sym хранит имя символа (индекс в strtab)?", "st_name"),
    ("Какое поле хранит значение (адрес) символа?", "st_value"),
    ("Какое поле хранит размер символа?", "st_size"),
    ("Какое поле хранит тип и привязку символа?", "st_info"),
    ("Какой макрос извлекает тип из st_info?", "ELF32_ST_TYPE"),
    ("Какой макрос извлекает binding из st_info?", "ELF32_ST_BIND"),
    ("Какое значение st_info binding означает STB_LOCAL?", "0"),
    ("Какое значение st_info binding означает STB_GLOBAL?", "1"),
    ("Какое значение st_info binding означает STB_WEAK?", "2"),
    ("Какое значение типа символа означает STT_NOTYPE?", "0"),
    ("Какое значение типа символа означает STT_OBJECT?", "1"),
    ("Какое значение типа символа означает STT_FUNC?", "2"),
    ("Какое значение типа символа означает STT_SECTION?", "3"),
    ("Какое значение типа символа означает STT_FILE?", "4"),
    ("Какое значение st_shndx означает SHN_UNDEF (неопределённый символ)?", "0"),
    ("Какое значение st_shndx означает SHN_ABS (абсолютный символ)?", "0xfff1"),
    ("Какое значение st_shndx означает SHN_COMMON?", "0xfff2"),
    ("Что хранит поле st_other?", "visibility"),
    ("Какое значение st_other/visibility означает STV_DEFAULT?", "0"),
    ("Какое значение st_other/visibility означает STV_HIDDEN?", "2"),
    ("Какое значение st_other/visibility означает STV_PROTECTED?", "3"),
    ("Какое поле хранит индекс секции, которой принадлежит символ?", "st_shndx"),
    ("Что вычисляет макрос ELF32_ST_INFO(b,t)?", "(b<<4)+(t&0xf)"),

    # ==================== 6. ПЕРЕМЕЩЕНИЯ / RELOCATIONS (Вопросы 141-160) ====================
    ("Какой тип записи перемещения содержит addend?", "Elf64_Rela"),
    ("Какой тип записи перемещения без addend?", "Elf64_Rel"),
    ("Сколько байт занимает Elf64_Rela?", "24"),
    ("Сколько байт занимает Elf32_Rela?", "12"),
    ("Какое поле записи перемещения хранит смещение?", "r_offset"),
    ("Какое поле записи перемещения хранит тип и индекс символа?", "r_info"),
    ("Какое поле есть только в Rela (не в Rel)?", "r_addend"),
    ("Какой макрос извлекает тип из r_info для ELF32?", "ELF32_R_TYPE"),
    ("Какой макрос извлекает индекс символа из r_info для ELF64?", "ELF64_R_SYM"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_64?", "1"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_PC32?", "2"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_PLT32?", "4"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_GLOB_DAT?", "6"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_JUMP_SLOT?", "7"),
    ("Какое значение типа перемещения x86-64 для R_X86_64_RELATIVE?", "8"),
    ("Какое значение типа перемещения для R_X86_64_NONE?", "0"),
    ("Как называется секция с записями перемещений для .plt?", ".rela.plt"),
    ("Как называется секция с глобальной таблицей адресов (GOT) для PLT?", ".got.plt"),
    ("Что такое GOT в контексте ELF?", "globaloffsettable"),
    ("Что такое PLT в контексте ELF?", "procedurelinkage"),

    # ==================== 7. DYNAMIC SECTION (Вопросы 161-180) ====================
    ("Какое поле тега динамической секции хранит тип?", "d_tag"),
    ("Какое значение d_tag означает DT_NULL (конец таблицы)?", "0"),
    ("Какое значение d_tag означает DT_NEEDED?", "1"),
    ("Какое значение d_tag означает DT_PLTRELSZ?", "2"),
    ("Какое значение d_tag означает DT_STRTAB?", "5"),
    ("Какое значение d_tag означает DT_SYMTAB?", "6"),
    ("Какое значение d_tag означает DT_RELA?", "7"),
    ("Какое значение d_tag означает DT_STRSZ?", "10"),
    ("Какое значение d_tag означает DT_INIT?", "12"),
    ("Какое значение d_tag означает DT_FINI?", "13"),
    ("Какое значение d_tag означает DT_SONAME?", "14"),
    ("Какое значение d_tag означает DT_RPATH?", "15"),
    ("Какое значение d_tag означает DT_REL?", "17"),
    ("Какое значение d_tag означает DT_JMPREL?", "23"),
    ("Сколько байт занимает запись Elf64_Dyn?", "16"),
    ("Как называется секция с динамической информацией?", ".dynamic"),
    ("Что указывает тег DT_NEEDED в динамической секции?", "library"),
    ("Что содержит тег DT_SONAME?", "libraryname"),
    ("Какое значение d_tag означает DT_GNU_HASH?", "0x6ffffef5"),
    ("Какое значение d_tag означает DT_FLAGS?", "30"),

    # ==================== 8. ТИПЫ ДАННЫХ / SIZES (Вопросы 181-200) ====================
    ("Сколько байт занимает Elf64_Addr?", "8"),
    ("Сколько байт занимает Elf32_Addr?", "4"),
    ("Сколько байт занимает Elf64_Off?", "8"),
    ("Сколько байт занимает Elf32_Off?", "4"),
    ("Сколько байт занимает Elf64_Half?", "2"),
    ("Сколько байт занимает Elf64_Word?", "4"),
    ("Сколько байт занимает Elf64_Xword?", "8"),
    ("Сколько байт занимает Elf64_Phdr (заголовок программного сегмента)?", "56"),
    ("Сколько байт занимает Elf32_Phdr?", "32"),
    ("Сколько байт занимает Elf64_Shdr (заголовок секции)?", "64"),
    ("Сколько байт занимает Elf32_Shdr?", "40"),
    ("Какой тип используется для e_machine в Elf32_Ehdr?", "Elf32_Half"),
    ("Какой тип используется для sh_flags в Elf64_Shdr?", "Elf64_Xword"),
    ("Какой тип используется для p_flags в Elf64_Phdr?", "Elf64_Word"),
    ("Какой тип используется для st_value в Elf64_Sym?", "Elf64_Addr"),
    ("Какое значение EI_OSABI для FreeBSD?", "9"),
    ("Какое значение EI_OSABI для NetBSD?", "2"),
    ("Какое значение e_machine для IA-64 (EM_IA_64)?", "50"),
    ("Какое значение e_machine для SPARC (EM_SPARC)?", "2"),
    ("Как называется первый байт ELF-файла (значение 0x7f) по стандарту?", "ELFMAG0"),
]


def create_minimal_elf():
    """Создаёт минимальный корректный 64-битный ELF-файл (ET_EXEC, x86-64)"""
    # e_ident (16 байт)
    e_ident = bytearray(16)
    e_ident[0:4] = b'\x7fELF'   # Magic
    e_ident[4] = 2               # EI_CLASS: ELFCLASS64
    e_ident[5] = 1               # EI_DATA: ELFDATA2LSB (little-endian)
    e_ident[6] = 1               # EI_VERSION: EV_CURRENT
    e_ident[7] = 0               # EI_OSABI: ELFOSABI_NONE
    # e_ident[8..15] = 0 (padding)

    ENTRY_POINT   = 0x401000
    PHOFF         = 64            # сразу после ELF header
    PH_ENTRY_SIZE = 56
    PH_COUNT      = 1
    SHOFF         = 0             # нет секций (упрощение)

    # ELF64 Header (64 байта)
    ehdr = bytearray(64)
    ehdr[0:16] = e_ident
    struct.pack_into('<H', ehdr, 16, 2)           # e_type: ET_EXEC
    struct.pack_into('<H', ehdr, 18, 62)          # e_machine: EM_X86_64
    struct.pack_into('<I', ehdr, 20, 1)           # e_version: EV_CURRENT
    struct.pack_into('<Q', ehdr, 24, ENTRY_POINT) # e_entry
    struct.pack_into('<Q', ehdr, 32, PHOFF)       # e_phoff
    struct.pack_into('<Q', ehdr, 40, SHOFF)       # e_shoff (0 = нет)
    struct.pack_into('<I', ehdr, 48, 0)           # e_flags
    struct.pack_into('<H', ehdr, 52, 64)          # e_ehsize
    struct.pack_into('<H', ehdr, 54, PH_ENTRY_SIZE) # e_phentsize
    struct.pack_into('<H', ehdr, 56, PH_COUNT)    # e_phnum
    struct.pack_into('<H', ehdr, 58, 64)          # e_shentsize
    struct.pack_into('<H', ehdr, 60, 0)           # e_shnum
    struct.pack_into('<H', ehdr, 62, 0)           # e_shstrndx

    # Одна PT_LOAD секция (56 байт)
    phdr = bytearray(56)
    struct.pack_into('<I', phdr, 0,  1)           # p_type: PT_LOAD
    struct.pack_into('<I', phdr, 4,  5)           # p_flags: PF_R | PF_X
    struct.pack_into('<Q', phdr, 8,  0)           # p_offset (от начала файла)
    struct.pack_into('<Q', phdr, 16, 0x400000)    # p_vaddr
    struct.pack_into('<Q', phdr, 24, 0x400000)    # p_paddr
    struct.pack_into('<Q', phdr, 32, 0x1000)      # p_filesz
    struct.pack_into('<Q', phdr, 40, 0x1000)      # p_memsz
    struct.pack_into('<Q', phdr, 48, 0x1000)      # p_align

    # Тело файла: заглушка кода (до 0x1000 байт)
    # xor eax, eax; inc eax; int 0x80 — выход из программы (Linux x86-64 stub)
    code = bytearray(0x1000)
    stub = bytes([
        0x48, 0x31, 0xFF,          # xor rdi, rdi
        0x48, 0xC7, 0xC0, 0x3C,
        0x00, 0x00, 0x00,          # mov rax, 60 (sys_exit)
        0x0F, 0x05                 # syscall
    ])
    code[0x1000 - len(stub) - 64 - 56:] = stub[:len(stub)]

    elf = bytes(ehdr) + bytes(phdr) + bytes(code)
    return elf


def create_theory_lab():
    """Создаёт лабораторную работу с 200 теоретическими вопросами по ELF"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Находим ID группы КС-22-03 (или создаём если нет)
    c.execute("SELECT id FROM groups WHERE name = 'КС-22-03'")
    group = c.fetchone()
    if not group:
        c.execute("INSERT INTO groups (name, size) VALUES (?, ?)", ('КС-22-03', 25))
        conn.commit()
        c.execute("SELECT id FROM groups WHERE name = 'КС-22-03'")
        group = c.fetchone()
    group_id = group[0]

    lab_title = "Теория_ELF_hex_200вопросов"
    c.execute("SELECT id FROM labs WHERE title = ?", (lab_title,))
    existing = c.fetchone()

    if existing:
        lab_id = existing[0]
        # Удаляем старые данные
        c.execute(
            "DELETE FROM file_question_answers WHERE question_id IN "
            "(SELECT id FROM questions WHERE lab_id = ?)", (lab_id,)
        )
        c.execute("DELETE FROM questions WHERE lab_id = ?", (lab_id,))
        c.execute("DELETE FROM lab_files WHERE lab_id = ?", (lab_id,))
        c.execute("DELETE FROM lab_passwords WHERE lab_id = ?", (lab_id,))
    else:
        start_at    = datetime(2025, 2, 1, 0, 0, 0)
        deadline_at = datetime(2025, 12, 31, 23, 59, 59)
        c.execute(
            """INSERT INTO labs
               (title, code, start_at, deadline_at, description, is_test, questions_count, test_duration)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (lab_title, f"LAB9-{int(datetime.now().timestamp())}",
             start_at, deadline_at, "", 1, 50, 90)
        )
        conn.commit()
        lab_id = c.lastrowid

    # Привязываем группу к ЛР
    c.execute("DELETE FROM lab_groups WHERE lab_id = ?", (lab_id,))
    c.execute("INSERT INTO lab_groups (lab_id, group_id) VALUES (?, ?)", (lab_id, group_id))

    # Создаём минимальный ELF-файл как эталонный файл для лабы
    files_dir = os.path.join(LABS_DIR, str(lab_id))
    os.makedirs(files_dir, exist_ok=True)

    elf_data = create_minimal_elf()
    elf_path = os.path.join(files_dir, "theory_reference.elf")
    with open(elf_path, "wb") as f:
        f.write(elf_data)

    c.execute("INSERT INTO lab_files (lab_id, file_path) VALUES (?, ?)", (lab_id, elf_path))
    conn.commit()
    file_id = c.lastrowid

    # Добавляем 200 вопросов
    for question_text, answer in THEORY_QUESTIONS:
        c.execute("INSERT INTO questions (lab_id, text) VALUES (?, ?)", (lab_id, question_text))
        question_id = c.lastrowid
        c.execute(
            "INSERT INTO file_question_answers (lab_file_id, question_id, correct_answer) VALUES (?, ?, ?)",
            (file_id, question_id, answer)
        )

    conn.commit()
    conn.close()

    print(f"Создана лабораторная работа '{lab_title}' с ID={lab_id}")
    print(f"Добавлено {len(THEORY_QUESTIONS)} вопросов")
    return lab_id


def create_protection_for_lab9():
    """Создаёт защиту для 9 лабораторной работы (ELF анализ)"""
    import string
    import secrets

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Ищем все ЛР, связанные с 9 лабой или ELF
    c.execute(
        "SELECT id, title FROM labs WHERE title LIKE '%9%' OR title LIKE '%ELF%'"
    )
    lab9_list = c.fetchall()

    print(f"Найдено лабораторных работ, связанных с 9 лабой: {len(lab9_list)}")

    for lab_id, lab_title in lab9_list:
        print(f"  Обработка ЛР #{lab_id}: {lab_title}")

        c.execute("SELECT COUNT(*) FROM lab_passwords WHERE lab_id = ?", (lab_id,))
        count = c.fetchone()[0]

        if count == 0:
            c.execute("SELECT id FROM lab_files WHERE lab_id = ?", (lab_id,))
            files = c.fetchall()

            for (file_id,) in files:
                password = ''.join(
                    secrets.choice(string.ascii_uppercase + string.digits)
                    for _ in range(10)
                )
                c.execute(
                    "INSERT INTO lab_passwords (lab_id, file_id, password) VALUES (?, ?, ?)",
                    (lab_id, file_id, password)
                )

            conn.commit()
            print(f"    Сгенерированы пароли для {len(files)} файлов")
        else:
            print(f"    Пароли уже существуют ({count} шт)")

    conn.close()
    print("Защита для 9 лабы создана/обновлена")


if __name__ == "__main__":
    print("=== Создание 200 теоретических вопросов по ELF (9 лаба) ===")
    create_theory_lab()

    print("\n=== Создание защиты для 9 лабораторной работы ===")
    create_protection_for_lab9()

    print("\n=== Готово! ===")