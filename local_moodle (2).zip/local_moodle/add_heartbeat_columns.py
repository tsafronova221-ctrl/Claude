"""
Резервный способ добавить колонки без flask db upgrade.
Запустить: python add_heartbeat_columns.py
"""
import sqlite3, os, sys

db_path = os.path.join('instance', 'app.db')
if not os.path.exists(db_path):
    print(f"БД не найдена: {db_path}")
    sys.exit(1)

con = sqlite3.connect(db_path)
cur = con.cursor()

# Получаем существующие колонки
cur.execute("PRAGMA table_info(attempts)")
existing = {row[1] for row in cur.fetchall()}

added = []
if 'heartbeat_count' not in existing:
    cur.execute("ALTER TABLE attempts ADD COLUMN heartbeat_count INTEGER NOT NULL DEFAULT 0")
    added.append('heartbeat_count')
if 'last_heartbeat_at' not in existing:
    cur.execute("ALTER TABLE attempts ADD COLUMN last_heartbeat_at DATETIME")
    added.append('last_heartbeat_at')
if 'heartbeat_nonce' not in existing:
    cur.execute("ALTER TABLE attempts ADD COLUMN heartbeat_nonce VARCHAR(64)")
    added.append('heartbeat_nonce')

con.commit()
con.close()

if added:
    print(f"✅ Добавлены колонки: {', '.join(added)}")
else:
    print("✅ Все колонки уже существуют — ничего не изменено")
