"""Add index on attempts for open test queries (used by expiry scheduler)

Revision ID: 002_idx_attempts_open
Revises: 001_add_violations_and_duration
Create Date: 2026-04-16
"""
from alembic import op

revision = '002_idx_attempts_open'
down_revision = '001_add_violations_and_duration'
branch_labels = None
depends_on = None


def upgrade():
    # Ускоряет запрос планировщика: незавершённые попытки тестов
    op.create_index(
        'ix_attempts_open_tests',
        'attempts',
        ['finished_at', 'lab_id'],
    )


def downgrade():
    op.drop_index('ix_attempts_open_tests', table_name='attempts')
