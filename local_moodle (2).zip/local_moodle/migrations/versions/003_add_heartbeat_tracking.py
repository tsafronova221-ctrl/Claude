"""Add server-side heartbeat tracking columns to attempts

Revision ID: 003_add_heartbeat_tracking
Revises: 002_idx_attempts_open
Create Date: 2026-04-23
"""
from alembic import op
import sqlalchemy as sa

revision = '003_add_heartbeat_tracking'
down_revision = '002_idx_attempts_open'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('attempts',
        sa.Column('heartbeat_count', sa.Integer(), nullable=False, server_default='0'))
    op.add_column('attempts',
        sa.Column('last_heartbeat_at', sa.DateTime(), nullable=True))
    op.add_column('attempts',
        sa.Column('heartbeat_nonce', sa.String(64), nullable=True))


def downgrade():
    op.drop_column('attempts', 'heartbeat_nonce')
    op.drop_column('attempts', 'last_heartbeat_at')
    op.drop_column('attempts', 'heartbeat_count')
