# -*- coding: utf-8 -*-
"""
Точка входа приложения.
Загружает переменные окружения из .env ДО инициализации Flask.
"""
from pathlib import Path
import os

# ── Загрузка .env (если есть python-dotenv) ─────────────────────────────────
try:
    from dotenv import load_dotenv
    _env_file = Path(__file__).parent / ".env"
    if _env_file.exists():
        load_dotenv(_env_file)
except ImportError:
    pass  # python-dotenv не установлен — читаем из системных переменных окружения

# ── Теперь создаём приложение (Config уже видит переменные) ─────────────────
from app import create_app
import urllib.parse
from flask import request, abort, send_file

app = create_app()
app.config['SESSION_COOKIE_NAME'] = 'session5000'

BASE_DIR        = Path(os.path.dirname(os.path.abspath(__file__))).resolve()
INSTANCE_LABS   = BASE_DIR / "instance" / "labs"
INSTANCE_PROT   = BASE_DIR / "instance" / "protections"
ALLOWED_DIRS    = [INSTANCE_LABS, INSTANCE_PROT]

FORBIDDEN_EXT = {
    '.py', '.pyc', '.pyo', '.db', '.sqlite', '.sql',
    '.env', '.git', '.json', '.yml', '.yaml', '.ini',
    '.conf', '.config', '.pem', '.key', '.crt', '.log',
}

# ── Legacy /files/ route: защита от path-traversal ──────────────────────────
@app.before_request
def _guard_files():
    if '/files/' not in request.path:
        return
    raw = request.path.split('/files/', 1)[-1]
    decoded = urllib.parse.unquote(raw)
    if '\\' in decoded or '..' in decoded.split('/'):
        abort(400)
    if not (decoded.startswith('instance/labs/') or
            decoded.startswith('instance/protections/')):
        abort(403)
    if any(decoded.lower().endswith(e) for e in FORBIDDEN_EXT):
        abort(403)


@app.route("/files/<path:file_path>")
def files(file_path):
    """Устаревший маршрут — оставлен для совместимости, работает через ID теперь."""
    if not (file_path.startswith('instance/labs/') or
            file_path.startswith('instance/protections/')):
        abort(403)
    parts = file_path.replace('instance/', '', 1).split('/')
    inner = '/'.join(parts[1:]) if len(parts) > 1 else ''
    for d in ALLOWED_DIRS:
        if not d.exists():
            continue
        full = (d / inner).resolve()
        try:
            full.relative_to(d.resolve())
        except ValueError:
            abort(403)
        if full.is_file():
            return send_file(full)
    abort(404)


if __name__ == "__main__":
    debug = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(host="0.0.0.0", port=5000, debug=debug)
