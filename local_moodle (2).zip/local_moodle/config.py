import os
import sys


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', '')
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', "sqlite:///../instance/app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    @classmethod
    def validate(cls):
        """Проверка критических настроек при старте. Падает с ошибкой, если не настроено."""
        errors = []
        if not cls.SECRET_KEY or cls.SECRET_KEY in ('CHANGE_ME', 'CHANGE_ME_IN_PRODUCTION_SET_ENV_VAR'):
            errors.append(
                "SECRET_KEY не задан или использует значение по умолчанию.\n"
                "  Сгенерируйте ключ: python -c \"import secrets; print(secrets.token_hex(32))\""
            )
        if errors:
            print("\n" + "=" * 60, file=sys.stderr)
            print("FATAL: Небезопасная конфигурация — приложение не запущено.", file=sys.stderr)
            for e in errors:
                print(f"\n  [!] {e}", file=sys.stderr)
            print("=" * 60 + "\n", file=sys.stderr)
            sys.exit(1)
